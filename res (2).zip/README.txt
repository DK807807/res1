===================================================================
        Thank you for Downloading this resource pack.
===================================================================

[ PLS READ THIS ]
-This resource pack is made by lapietous.
-You can edit or modify this resource pack for PERSONAL use.
-Do NOT REPOST and redistribute my work, including any assets inside it or the whole resource pack.
-If you saw someone reposting or distributing of my works, pls report it. I greatly appreciate it.

===================================================================
                         MY LINKS
===================================================================

PMC: 
 - https://www.planetminecraft.com/member/lapietous

Curseforge:
 - https://www.curseforge.com/members/lapietous

Modrinth:
 - https://modrinth.com/user/Lapietous

Skindex:
 - https://www.minecraftskins.com/profile/9107243/lapietous

===================================================================
                       ALL TOTEM NAMES
===================================================================

[ NOTE ]
-The number in the names below represents your custom skin slot. 
-Change the "1" to whichever number you are using.
(Example: "player 2", "player plush 5")

STANDARD 3D PLAYER:
  - player 1
  - player 1 slim (For smaller arms)

PLUSH:
  - player plush 1
  - player plush 1 slim (For smaller arms)

2D TOTEM SHAPE:
  - player totem 1

SITTING PLAYER POSE:
  - player sit 1
  - player sit 1 slim (For smaller arms)

===================================================================
                       ВСЕ НАЗВАНИЯ ТОТЕМОВ
===================================================================

[ ПРИМЕЧАНИЕ ]
- Число в названиях ниже обозначает слот вашего кастомного скина.
- Измените «1» на номер, который вы используете.
(Пример: "player 2", "player plush 5")

СТАНДАРТНЫЙ 3D ИГРОК:
  - player 1
  - player 1 slim (Для тонких рук)

ПЛЮШЕВАЯ ИГРУШКА:
  - player plush 1
  - player plush 1 slim (Для тонких рук)

2D ФОРМА ТОТЕМА:
  - player totem 1

ПОЗА СИДЯЩЕГО ИГРОКА:
  - player sit 1
  - player sit 1 slim (Для тонких рук)

===================================================================
                       すべてのトーテム名
===================================================================

[ 注意事項 ]
- 以下の名前にある数字は、カスタムスキンのスロット番号を表しています。
- 「1」を、使用する番号に変更してください。
（例："player 2"、"player plush 5"）

標準の3Dプレイヤー:
  - player 1
  - player 1 slim（細い腕用）

ぬいぐるみ:
  - player plush 1
  - player plush 1 slim（細い腕用）

2Dトーテムの形状:
  - player totem 1

座っているプレイヤーのポーズ:
  - player sit 1
  - player sit 1 slim（細い腕用）

===================================================================
                    TODOS LOS NOMBRES DE TÓTEMS
===================================================================

[ NOTA ]
- El número en los nombres a continuación representa el espacio de tu skin personalizada.
- Cambia el "1" al número que estés utilizando.
(Ejemplo: "player 2", "player plush 5")

JUGADOR 3D ESTÁNDAR:
  - player 1
  - player 1 slim (Para brazos más pequeños)

PELUCHE:
  - player plush 1
  - player plush 1 slim (Para brazos más pequeños)

FORMA DE TÓTEM 2D:
  - player totem 1

POSE DE JUGADOR SENTADO:
  - player sit 1
  - player sit 1 slim (Para brazos más pequeños)

===================================================================
