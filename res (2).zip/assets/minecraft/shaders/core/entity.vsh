#version 330
#extension GL_ARB_separate_shader_objects : require
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:blink.glsl>
layout(location=0)in vec3 Position;layout(location=1)in vec4 Color;layout(location=2)in vec2 UV0;layout(location=3)in ivec2 UV1;layout(location=4)in ivec2 UV2;layout(location=5)in vec3 Normal;uniform sampler2D Sampler0;
#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif
#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif
layout(location=0)out float sphericalVertexDistance;layout(location=1)out float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location=2)out vec4 vertexPerFaceColorBack;layout(location=3)out vec4 vertexPerFaceColorFront;
#else
layout(location=2)out vec4 vertexColor;
#endif
#ifndef EMISSIVE
layout(location=4)out vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
layout(location=5)out vec4 overlayColor;
#endif
layout(location=6)out vec2 texCoord0;
#ifdef GLINT
layout(location=7)out vec2 texCoordGlint;
#endif
layout(location=8)flat out float blinkClosed;layout(location=9)flat out float blinkVerdict;layout(location=10)flat out float blinkWink;float luma(vec3 c){return dot(c,vec3(0.299,0.587,0.114));}vec4 skinAt(int x,int y){return textureLod(Sampler0,(vec2(float(x),float(y))+0.5)/64.0,0.0);}float lumAt(int x,int y){return luma(skinAt(x,y).rgb)*255.0;}bool nearColor(vec3 c,vec3 ref){return distance(c,ref)*255.0<=25.0;}bool fpMatch(vec3 pupil,vec3 lid,vec3 cheek,vec3 pRef,vec3 lRef,vec3 cRef){return nearColor(pupil,pRef)&&nearColor(lid,lRef)&&nearColor(cheek,cRef);}bool isDefaultSkin(){vec3 pupil=skinAt(10,12).rgb;vec3 lid=skinAt(10,11).rgb;vec3 cheek=skinAt(8,13).rgb;return fpMatch(pupil,lid,cheek,vec3(0.3216,0.2392,0.5373),vec3(0.7020,0.4745,0.3686),vec3(0.6078,0.3882,0.2863))||fpMatch(pupil,lid,cheek,vec3(0.1373,0.3843,0.1412),vec3(0.8980,0.5529,0.2471),vec3(0.9373,0.8549,0.7490))||fpMatch(pupil,lid,cheek,vec3(0.1412,0.0118,0.0118),vec3(0.9765,0.6549,0.5255),vec3(0.9451,0.5059,0.4314))||fpMatch(pupil,lid,cheek,vec3(0.0000,0.0000,0.0000),vec3(0.2196,0.2196,0.2196),vec3(0.9490,0.6235,0.3725))||fpMatch(pupil,lid,cheek,vec3(0.3451,0.1725,0.1137),vec3(0.6627,0.3373,0.2275),vec3(0.7255,0.4039,0.2902))||fpMatch(pupil,lid,cheek,vec3(0.2549,0.1176,0.0078),vec3(0.4941,0.3255,0.2157),vec3(0.5725,0.4039,0.2980))||fpMatch(pupil,lid,cheek,vec3(0.1804,0.0941,0.0000),vec3(0.2667,0.2078,0.1569),vec3(0.3529,0.2706,0.2039))||fpMatch(pupil,lid,cheek,vec3(0.2627,0.4039,0.3255),vec3(0.8745,0.5882,0.3451),vec3(0.9882,0.9569,0.6667))||fpMatch(pupil,lid,cheek,vec3(0.4118,0.1686,0.2039),vec3(0.6706,0.4471,0.2980),vec3(0.5843,0.4196,0.6196));}bool pairHit(int wc,int pc,int r0,int r1,float skinLum){float w0=lumAt(wc,r0);float w1=lumAt(wc,r1);float p0=lumAt(pc,r0);float p1=lumAt(pc,r1);if(w0-p0<8.0||w1-p1<8.0){return false;}if((p0+p1)*0.5>=skinLum-20.0){return false;}if(min(p0,p1)>=skinLum-30.0){return false;}return true;}bool structureHit(){float skinLum=(lumAt(11,14)+lumAt(12,14)+lumAt(11,15)+lumAt(12,15))*0.25;if(skinLum<160.0){return false;}bool left=pairHit(9,10,12,13,skinLum)||pairHit(9,10,13,14,skinLum)||pairHit(10,11,12,13,skinLum)||pairHit(10,11,13,14,skinLum);bool right=pairHit(14,13,12,13,skinLum)||pairHit(14,13,13,14,skinLum)||pairHit(13,12,12,13,skinLum)||pairHit(13,12,13,14,skinLum);return left&&right;}float skinHash(){vec3 c=textureLod(Sampler0,(vec2(8.0,8.0)+0.5)/64.0,0.0).rgb;vec3 q=floor(c*255.0+0.5);float h=q.r*137.0+q.g*89.0+q.b*71.0;return mod(h,1021.0);}float blinkSeed(){return skinHash()/1021.0;}vec2 blinkRand(float k){float base=skinHash();return vec2(mod(k*137.0+base*71.0,1021.0),mod(k*613.0+k*k*11.0+base*29.0,1021.0))/1021.0;}void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);
#ifdef PER_FACE_LIGHTING
vec2 light=minecraft_compute_light(Light0_Direction,Light1_Direction,Normal);vertexPerFaceColorBack=minecraft_mix_light_separate(-light,Color);vertexPerFaceColorFront=minecraft_mix_light_separate(light,Color);
#elif defined(NO_CARDINAL_LIGHTING)
vertexColor=Color;
#else
vertexColor=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,Color);
#endif
#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
lightMapColor=sample_lightmap(Sampler2,UV2);
#endif
#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
overlayColor=texelFetch(Sampler1,UV1,0);
#endif
texCoord0=UV0;
#ifdef APPLY_TEXTURE_MATRIX
texCoord0=(TextureMat*vec4(UV0,0.0,1.0)).xy;
#endif
#ifdef GLINT
texCoordGlint=(TextureMat*vec4(UV0,0.0,1.0)).xy;
#endif
blinkVerdict=0.0;vec2 fp=UV0*64.0;if(all(greaterThanEqual(fp,vec2(7.5)))&&all(lessThanEqual(fp,vec2(16.5)))){if(isDefaultSkin()){blinkVerdict=1.0;}else if(structureHit()){blinkVerdict=2.0;}}float t=GameTime*1200.0+blinkSeed()*BLINK_INTERVAL;float cyc=floor(t/BLINK_INTERVAL);vec2 rnd=blinkRand(cyc);bool wink=(blinkVerdict>1.5)&&(rnd.x<WINK_CHANCE);blinkClosed=(mod(t,BLINK_INTERVAL)<CLOSED_TIME)?1.0:0.0;blinkWink=(blinkClosed>0.5&&wink)?((rnd.y<0.5)?-1.0:1.0):0.0;}
