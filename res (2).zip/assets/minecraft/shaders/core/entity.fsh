#version 330
#extension GL_ARB_separate_shader_objects : require
#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:blink.glsl>
#include <minecraft:oit.glsl>
uniform sampler2D Sampler0;
#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif
#ifdef GLINT
uniform sampler2D GlintSampler;
#endif
layout(location=0)in float sphericalVertexDistance;layout(location=1)in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location=2)in vec4 vertexPerFaceColorBack;layout(location=3)in vec4 vertexPerFaceColorFront;
#else
layout(location=2)in vec4 vertexColor;
#endif
#ifndef EMISSIVE
layout(location=4)in vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
layout(location=5)in vec4 overlayColor;
#endif
layout(location=6)in vec2 texCoord0;
#ifdef GLINT
layout(location=7)in vec2 texCoordGlint;
#endif
layout(location=8)flat in float blinkClosed;layout(location=9)flat in float blinkVerdict;layout(location=10)flat in float blinkWink;
#ifndef OIT_ALPHA_ONLY
layout(location=0)out vec4 fragColor;
#endif
vec4 calculateFinalColor(vec4 color){
#ifndef NO_OVERLAY
color.rgb=mix(overlayColor.rgb,color.rgb,overlayColor.a);
#endif
#ifndef EMISSIVE
color*=lightMapColor;
#endif
#ifdef GLINT
vec4 glintColor=GlintAlpha*texture(GlintSampler,texCoordGlint);color.rgb+=glintColor.rgb*glintColor.rgb;
#endif
#ifdef OIT_ACCUMULATE
color=sampleColorForAccumulation(color);vec4 fogColor=vec4(FogColor.rgb*color.a,FogColor.a);
#else
vec4 fogColor=FogColor;
#endif
return apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,fogColor);}vec4 skinAt(int x,int y){return textureLod(Sampler0,(vec2(float(x),float(y))+0.5)/64.0,0.0);}bool inEyeCols(int x){return(x>=9&&x<=10)||(x>=13&&x<=14);}bool winkSkips(int x){if(blinkWink<-0.5){return(x>=13&&x<=14);}if(blinkWink>0.5){return(x>=9&&x<=10);}return false;}void main(){vec4 color=texture(Sampler0,texCoord0);int cx=int(floor(texCoord0.x*64.0));int cy=int(floor(texCoord0.y*64.0));if(DEBUG>0&&cx>=8&&cx<=15&&cy>=8&&cy<=15){vec3 tint=blinkVerdict>1.5?vec3(1.0,1.0,0.0):blinkVerdict>0.5?vec3(0.0,1.0,0.0):vec3(1.0,0.0,0.0);color.rgb=mix(color.rgb,tint,0.5);}if(blinkClosed>0.5){if(blinkVerdict>1.5){if(inEyeCols(cx)&&!winkSkips(cx)){if(cy==14){int srcX=(cx<=10)?9:14;vec4 brow=skinAt(srcX,12);if(brow.a>0.5){color=brow;}}else if(cy==13||cy==12){vec4 sampled=skinAt(12,13);if(sampled.a>0.5){color.rgb=(cy==12)?mix(sampled.rgb,vec3(1.0),0.30):sampled.rgb;}}}}else if(blinkVerdict>0.5){if(cy==12){if(cx==9||cx==10){color=skinAt(10,13);}else if(cx==13||cx==14){color=skinAt(13,13);}}}}
#ifdef OIT_ADDITIVE
color.a=min(0.99,color.a);
#endif
#ifdef ALPHA_CUTOUT
if(color.a<ALPHA_CUTOUT){discard;}
#endif
#ifdef PER_FACE_LIGHTING
vec4 faceVertexColor=gl_FrontFacing?vertexPerFaceColorFront:vertexPerFaceColorBack;
#else
vec4 faceVertexColor=vertexColor;
#endif
#ifdef DISSOLVE
if(faceVertexColor.a<texture(DissolveMaskSampler,texCoord0).a){discard;}faceVertexColor.a=1.0;
#endif
color*=faceVertexColor*ColorModulator;
#ifdef GLINT
color.a=max(color.a,GlintAlpha);
#endif
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z,color.a);
#else
fragColor=calculateFinalColor(color);
#endif
}
