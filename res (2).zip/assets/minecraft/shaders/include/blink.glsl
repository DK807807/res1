// 眨眼参数
// 修改效果，在最下面四行数字生效
//   BLINK_INTERVAL：眨眼间隔（秒）
//   CLOSED_TIME   ：闭眼时长（秒）
//   WINK_CHANCE   ：单眼眨眼概率 
//   0.0 = 永远不wink；0.50 = 50% 的眨眼会wink；1.0 = 100%wink！（只对结构通过皮肤生效）
//   DEBUG：调试开关（整数）  0 = 关；1 = 开（查看你的皮肤结构是否通过）
// （绿 = 默认皮肤，黄 = 结构通过皮肤，红 = 判定不过）

const float BLINK_INTERVAL = 4.0;
const float CLOSED_TIME    = 0.15;
const float WINK_CHANCE    = 0.20;

const int DEBUG = 0;
