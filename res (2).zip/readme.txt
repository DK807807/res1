To access the plushies included in this pack,
rename a carved pumpkin in an anvil with the following
to apply the desired model:

- Enderman: Enderman, Enderman Plush, Enderman Plushie, enderman_plush, enderman_plushie
- Moose: Moose, Moose Plush, Moose Plushie, moose_plush, moose_plushie
- Chicken: Chicken, Chicken Plush, Chicken Plushie, chicken_plush, chicken_plushie
- Frog: Frog, Frog Plush, Frog Plushie, frog_plush, frog_plushie
- Iron Golem: Iron Golem, Golem Plush, Golem Plushie, iron_golem_plush, iron_golem_plushie
- Mooshroom: Mooshroom, Mooshroom Plush, Mooshroom Plushie, mooshroom_plush, mooshroom_plushie
- Fox: Fox, Fox Plush, Fox Plushie, fox_plush, fox_plushie
- Parrot: Parrot, Parrot Plush, Parrot Plushie, parrot_plush, parrot_plushie
- Slime: Slime, Slime Plush, Slime Plushie, slime_plush, slime_plushie
- Creeper: Creeper, Creeper Plush, Creeper Plushie, creeper_plush, creeper_plushie
- Sniffer: Sniffer, Sniffer Plush, Sniffer Plushie, sniffer_plush, sniffer_plushie
- Allay: Allay, Allay Plush, Allay Plushie, allay_plush, allay_plushie
- Dolphin: Dolphin, Dolphin Plush, Dolphin Plushie, dolphin_plush, dolphin_plushie
- Shulker: Shulker, Shulker Plush, Shulker Plushie, shulker_plush, shulker_plushie
- Pig: Pig, Pig Plush, Pig Plushie, pig_plush, pig_plushie
- Bee: Bee, Bee Plush, Bee Plushie, bee_plush, bee_plushie
