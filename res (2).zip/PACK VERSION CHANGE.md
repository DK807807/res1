\#HOW TO CHANGE THE PACK VERSION



Despite the description stating a specific Minecraft version, you can easily get it to work for other game versions like so:



1\. Open up the "pack.mcmeta" file in the downloaded zip file. If you can't open it, rename the file to "pack.txt".

2\. Change the number after "pack\_format" to your desired version number. These can be found with the link below.

3\. Next, press CTRL+S to save the file. Make sure the saved file's name is still "pack.mcmeta".

4\. Finally, drag the saved file back into the original zip folder. 

5\. Enjoy your pack!





Link to pack format version numbers: [https://minecraft.wiki/w/Pack\_format](https://minecraft.wiki/w/Pack_format) (Make sure you pick the right pack type, data or resource, as pack format numbers vary between types!)

